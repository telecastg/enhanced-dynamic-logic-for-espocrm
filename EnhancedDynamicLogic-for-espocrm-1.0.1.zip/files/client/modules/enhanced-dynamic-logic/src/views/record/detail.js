/************************************************************************
 * This file is part of EspoCRM.
 *
 * EspoCRM - Open Source CRM application.
 * Copyright (C) 2014-2019 Yuri Kuznetsov, Taras Machyshyn, Oleksiy Avramenko
 * Website: https://www.espocrm.com
 *
 * EspoCRM is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * EspoCRM is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with EspoCRM. If not, see http://www.gnu.org/licenses/.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "EspoCRM" word.
 * 
 * Enhanced Dynamic Logic - Open source plug in module for EspoCRM
 * Copyright (C) 2020 Omar A Gonsenheim
************************************************************************/

Espo.define('enhanced-dynamic-logic:views/record/detail', ['views/record/detail','enhanced-dynamic-logic:dynamic-logic'], function (Dep,EnhancedDynamicLogic) {

    return Dep.extend({
        
        dynamicCss:[],
        
        // override 'views/record/base method
        initDynamicLogic: function () {
            this.dynamicLogicDefs = Espo.Utils.clone(this.dynamicLogicDefs || {});
            this.dynamicLogicDefs.fields = Espo.Utils.clone(this.dynamicLogicDefs.fields);
            this.dynamicLogicDefs.panels = Espo.Utils.clone(this.dynamicLogicDefs.panels);
            // use the custom dynamic logic object instead of the default dynamic logic object 
            this.dynamicLogic = new EnhancedDynamicLogic(this.dynamicLogicDefs, this);
            this.listenTo(this.model, 'change', this.processDynamicLogic("change"), this);
            //this.processDynamicLogic('init');    
        },
        
        processDynamicLogic: function (event) {
            this.dynamicLogic.modelsArr.push(this.model);
            this.dynamicLogic.process();
        },

        afterRender: function () {
            this.initStickableButtonsContainer();
            this.initFieldsControlBehaviour();
            if(this.dynamicCss.length > 0) {
                this.processCss(this.dynamicCss);
            }
        },
        
        
        setFieldCss: function (cssData) {
            if(cssData) {
                this.dynamicCss = cssData;
            }
        },
        
        processCss: function(cssData) {
            cssData.forEach(function(fieldData){
                var fieldName = fieldData.field;
                var $fieldCell = $('div.field[data-name="' + fieldName + '"]');
                if($fieldCell.length > 0) {
                    var cssObj = {};
                    var cssArray = [];
                    var cssAttr = '';
                    var cssVal = '';
                    var cssStatements = fieldData.css.split(";");  
                    cssStatements.forEach(function(statement){
                        if(statement.length > 0) {
                            var cssArray = statement.split(":");
                            var cssAttr = cssArray[0];
                            var cssVal = cssArray[1];
                            if(cssAttr) {
                                cssObj[cssAttr] = cssVal
                            }
                            $fieldCell.css(cssObj);
                        }
                    });                        
                }
            });
        }
        
        
    });
});

/************************************************************************
 * This file is part of EspoCRM.
 *
 * EspoCRM - Open Source CRM application.
 * Copyright (C) 2014-2019 Yuri Kuznetsov, Taras Machyshyn, Oleksiy Avramenko
 * Website: https://www.espocrm.com
 *
 * EspoCRM is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * EspoCRM is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with EspoCRM. If not, see http://www.gnu.org/licenses/.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "EspoCRM" word.
 * 
 * Enhanced Dynamic Logic - Open source plug in module for EspoCRM
 * Copyright (C) 2020 Omar A Gonsenheim
************************************************************************/

Espo.define('enhanced-dynamic-logic:views/record/detail', ['views/record/detail','enhanced-dynamic-logic:enhanced-dynamic-logic'], function (Dep,EnhancedDynamicLogic) {

    return Dep.extend({
        
        dynamicLogicDefs: {},
        dynamicLogic: null,        
        userRoles:[],

        init: function() {
            // console.log("enhanced-dynamic-logic:views/record/detail.js init()");
            Dep.prototype.init.call(this);
        },
                
        // override method from 'views/record/base' 
        initDynamicLogic: function () {
            // console.log("enhanced-dynamic-logic:views/record/detail.js initDynamicLogic()");
            //this.dynamicLogicDefs = this.getMetadata().get('clientDefs.' + this.collection.entityType + '.dynamicLogic');
            this.dynamicLogicDefs = Espo.Utils.clone(this.dynamicLogicDefs || {});
            this.dynamicLogicDefs.fields = Espo.Utils.clone(this.dynamicLogicDefs.fields);
            this.dynamicLogicDefs.panels = Espo.Utils.clone(this.dynamicLogicDefs.panels);   
            // get the user roles and continue to function contInitDynamicLogic when done        
            this.getUserRoles();
        },
        
        // continue initializing Dynamic Logic definitions
        contInitDynamicLogic: function (roles) {
            // console.log("enhanced-dynamic-logic:views/record/detail.js contInitDynamicLogic()");
            this.dynamicLogicDefs.userRoles = roles;
            // instantiate the custom EnhancedDynamic object
            this.dynamicLogic = new EnhancedDynamicLogic(this.dynamicLogicDefs, this);    
            // add this model as target to which Dynamic Logic actions will apply
            // this is necessary because dynamic login in list view uses an array of models
            this.dynamicLogic.modelsArr = [this.model];
            this.dynamicLogic.viewMode = "detail";            
            // call this.processDynamicLogic when the model is freshly loaded
            this.listenTo(this,'after:render', function(){
                this.processDynamicLogic(); 
            },this);
            // create a listener to trigger function processDynamicLogic when the model changes
            this.listenTo(this.model, 'change', function(){
                // if the detail view is invoked from a list display, send a signal to halt triggering dynamic logic for the list too
                if(this.model.collection) {
                    this.model.collection.trigger('holdListDynamicLogicProcess',this);                    
                }
                this.processDynamicLogic();
            }, this);   
            // create a listener to release the hold on list dynamic logic processing when the model is saved if applicable
            this.listenToOnce(this, 'save', function () {
                if(this.model.collection) {
                    this.model.collection.trigger('releaseListDynamicLogicProcess',this);                    
                }
            }, this);

        },
        
        // override method from 'views/record/base'
        processDynamicLogic: function () { 
            // console.log("enhanced-dynamic-logic:views/record/detail.js processDynamicLogic()");
            // execute the dynamic logic process
            this.dynamicLogic.process();
        },

        // function invoked by enhanced-dynamic-logic:enhanced-dynamic-logic.js        
        setFieldCss: function (cssData) {            
            this.processCss(cssData);
        },
        
        processCss: function(cssData) {
            cssData.forEach(function(fieldData){
                var fieldName = fieldData.field;
                var $fieldCell = $('div.field[data-name="' + fieldName + '"]');
                if($fieldCell.length > 0) {
                    var cssObj = {};
                    var cssArray = [];
                    var cssAttr = '';
                    var cssVal = '';
                    var cssStatements = fieldData.css.split(";");  
                    cssStatements.forEach(function(statement){
                        if(statement.length > 0) {
                            var cssArray = statement.split(":");
                            var cssAttr = cssArray[0];
                            var cssVal = cssArray[1];
                            if(cssAttr) {
                                cssObj[cssAttr] = cssVal;
                            }
                            $fieldCell.css(cssObj);
                        }
                    });                        
                }
            });
        },

        getUserRoles: function() {
            var userId = this.getUser().id;
            // console.log("enhanced-dynamic-logic:views/record/detail.js userId = ",userId);
            var options = {};
            if(this.getUser().attributes.isPortalUser) {
                var sqlString = "SELECT portal_role.name FROM portal_role INNER JOIN portal_role_user ON portal_role_user.portal_role_id = portal_role.id WHERE portal_role_user.user_id = '"+userId+"'";
            } else {
                var sqlString = "SELECT role.name FROM role_user INNER JOIN user ON role_user.user_id = user.id INNER JOIN role ON role_user.role_id = role.id WHERE user.id = '"+userId+"'";                
            }
            // console.log("enhanced-dynamic-logic:views/record/detail.js this.getUser().attributes.isPortalUser = ",this.getUser().attributes.isPortalUser);
            
            options.sqlString = sqlString;     
            options.queryType = "SELECT";
            var url = '?entryPoint=edlSqlDataDispatcher';
            var payload = JSON.stringify(options); 
            var xmlhttp = new XMLHttpRequest();
            var self = this;
            xmlhttp.onreadystatechange = function() {                
                if (xmlhttp.readyState === XMLHttpRequest.DONE) {   // XMLHttpRequest.DONE == 4
                    // if the ajax call is successful load the userRoles array
                    if (xmlhttp.status === 200) {
                        var responseObj = JSON.parse(xmlhttp.responseText);
                        var roles = [];
                        options.responseObj = responseObj;
                        responseObj.forEach(function (role) {
                            roles.push(role.name);                            
                        }); 
                        // console.log("enhanced-dynamic-logic:views/record/detail.js responseObj = ",responseObj);
                        // console.log("enhanced-dynamic-logic:views/record/detail.js roles = ",roles);
                        self.contInitDynamicLogic(roles);                        
                    }
                    else if (xmlhttp.status === 400) {
                        alert('There was an error 400');
                    }
                    else {
                        alert('something else other than 200 was returned');
                    }                    
                }                
            };
            xmlhttp.open("POST",url , true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");                
            xmlhttp.send("data="+payload);              
        },
        
        initDynamicHandler: function () {
            // console.log("enhanced-dynamic-logic:views/record/detail.js initDynamicHandler()");
            var dynamicHandlerClassName = this.dynamicHandlerClassName ||
                this.getMetadata().get(['clientDefs', this.scope, 'dynamicHandler']);
            var init = function (dynamicHandler) {
                this.listenTo(this.model, 'change', function (model, o) {
                    if ('onChange' in dynamicHandler) {
                        dynamicHandler.onChange.call(dynamicHandler, model, o);
                    }

                    var changedAttributes = model.changedAttributes();
                    for (var attribute in changedAttributes) {
                        var methodName = 'onChange' + Espo.Utils.upperCaseFirst(attribute);
                        if (methodName in dynamicHandler) {
                            dynamicHandler[methodName].call(dynamicHandler, model, changedAttributes[attribute], o);
                        }
                    }
                }, this);

                if ('init' in dynamicHandler) {
                    dynamicHandler.init();
                }
            }.bind(this);

            if (dynamicHandlerClassName) {
                this.wait(
                    new Promise(
                        function (resolve) {
                            require(dynamicHandlerClassName, function (DynamicHandler) {
                                var dynamicHandler = this.dynamicHandler = new DynamicHandler(this);
                                init(dynamicHandler);
                                resolve();
                            }.bind(this));
                        }.bind(this)
                    )
                );
            }

            var handlerList = this.getMetadata().get(['clientDefs', this.scope, 'dynamicHandlerList']) || [];
            if (handlerList.length) {
                var self = this;
                var promiseList = [];

                handlerList.forEach(function (className, i) {
                    promiseList.push(
                        new Promise(
                            function (resolve) {
                                require(className, function (DynamicHandler) {
                                    resolve(new DynamicHandler(self));
                                });
                            }
                        )
                    );
                });

                this.wait(
                    Promise.all(promiseList).then(
                        function (list) {
                            list.forEach(function (dynamicHandler) {
                                init(dynamicHandler);
                            });
                        }
                    )
                );
            }
        }
                        
    });
});

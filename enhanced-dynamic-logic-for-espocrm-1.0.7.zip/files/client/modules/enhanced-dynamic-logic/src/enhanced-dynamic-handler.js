/************************************************************************
 * This file is part of EspoCRM.
 *
 * EspoCRM - Open Source CRM application.
 * Copyright (C) 2014-2020 Yuri Kuznetsov, Taras Machyshyn, Oleksiy Avramenko
 * Website: https://www.espocrm.com
 *
 * EspoCRM is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * EspoCRM is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with EspoCRM. If not, see http://www.gnu.org/licenses/.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "EspoCRM" word.
 * 
 * Enhanced Dynamic Logic - Open source plug in module for EspoCRM
 * Copyright (C) 2020 Omar A Gonsenheim
************************************************************************/

define('enhanced-dynamic-logic:enhanced-dynamic-handler', ['dynamic-handler'], function (Dep) {
    
    return Dep.extend({
    
        applyUserAttributes: false,
        
        applyCssDirectives: false,
        
        isUserAdmin: false,
        
        isUserPortal: false,
        
        userRoles: false,
        
        userTeams: false,
        
        controlFields: function() { 
            // this method is the start up method, meant to be defined 
            // in the specific dynamic handler implementation for each entity
        },
        
        init: function () {
            if(this.applyUserAttributes) {
                var userId = this.recordView.getUser().id;
                this.isUserAdmin = this.recordView.getUser().isAdmin();
                this.isUserPortal = this.recordView.getUser().isPortal();                 
                this.getUserTeams();
                this.getUserRoles(userId,'controlFields()');
            } else {
                this.controlFields();
            }
        },
        
        executeSql: function (options,responseType,callback){
            if(!options) {
                alert("'options' value missing when invoking 'executeSql' function ");
                return false;                
            }
            var url = '?entryPoint=edlSqlDataDispatcher';
            var payload = JSON.stringify(options); 
            var xmlhttp = new XMLHttpRequest();
            var self = this;
            xmlhttp.onreadystatechange = function() {                
                if (xmlhttp.readyState === XMLHttpRequest.DONE) {   
                    // if the ajax call is successful load the userRoles array
                    if (xmlhttp.status === 200) {
                        if(responseType === 'json') {
                            var serverResponse = JSON.parse(xmlhttp.responseText);                            
                        } else {
                            var serverResponse = xmlhttp.responseText;                                                         
                        }
                        if(callback) {
                            eval('self.'+callback+'('+serverResponse+')');                            
                        }
                    }
                    else if (xmlhttp.status === 400) {
                        alert('There was an error 400');
                    }
                    else {
                        alert('something else other than 200 was returned');
                    }                    
                }                
            };
            xmlhttp.open("POST",url , true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");                
            xmlhttp.send("data="+payload);                          
        },
        
        getForeignEntityFieldValue: function(params, callback) {
            if(!params) {
                alert("'params' value missing when invoking 'getEntityFieldValue' function ");
                return false;
            }            
            var options = {};                
            var foreignEntityType = params.foreignEntityType;
            var foreignEntityId = params.foreignEntityId;
            var foreignFieldName = params.foreignFieldName;
            var sqlString = "SELECT "+foreignEntityType+"."+foreignFieldName+" FROM "+foreignEntityType+" WHERE "+foreignEntityType+".id = '"+foreignEntityId+"' LIMIT 1";
            options.sqlString = sqlString;     
            options.queryType = "SELECT";
            this.executeSql(options, 'json', callback);            
        },
        
        getUserRoles: function(userId, callback) {    
            var options = {};
            var sqlString = "SELECT role.name FROM role_user INNER JOIN user ON role_user.user_id = user.id INNER JOIN role ON role_user.role_id = role.id WHERE user.id = '"+userId+"'";
            options.sqlString = sqlString;     
            options.queryType = "SELECT";
            var url = '?entryPoint=edlSqlDataDispatcher';
            var payload = JSON.stringify(options); 
            var xmlhttp = new XMLHttpRequest();
            var self = this;
            xmlhttp.onreadystatechange = function() {                
                if (xmlhttp.readyState === XMLHttpRequest.DONE) {   
                    // if the ajax call is successful load the userRoles array
                    if (xmlhttp.status === 200) {
                        var responseObj = JSON.parse(xmlhttp.responseText);
                        var roles = [];
                        options.responseObj = responseObj;
                        responseObj.forEach(function (role) {
                            roles.push(role.name);                            
                        }); 
                        self.userRoles = roles;
                        // if the implementation will modify field's css, 
                        // make sure that the field elements have been rendered
                        // or wait until the document has been rendered
                        if(self.applyCssDirectives) {
                            var $fieldCells = $('div.field');
                            if($fieldCells.length > 0) {                                 
                                //self.controlFields();   
                                eval('self.'+callback);
                            } else {
                                self.recordView.listenTo(self.recordView, 'after:render', function () {
                                    //self.controlFields
                                    eval('self.'+callback);
                                }, self);                                     
                            }
                        // if the implementation does not call for css modifications
                        // invoke the controlFields() start up function
                        } else {
                            //self.controlFields();
                            eval('self.'+callback);
                        }                        
                    }
                    else if (xmlhttp.status === 400) {
                        alert('There was an error 400');
                    }
                    else {
                        alert('something else other than 200 was returned');
                    }                    
                }                
            };
            xmlhttp.open("POST",url , true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");                
            xmlhttp.send("data="+payload);              
        },
        
        getUserTeams: function() {
            this.userTeams = Object.values(this.recordView.getUser().get('teamsNames'));            
        },

        setFieldCss: function(fieldName, fieldStyleString) {
            var $fieldCell = $('div.field[data-name="' + fieldName + '"]');
            if($fieldCell.length > 0) {                    
                var cssObj = {};
                var cssArray = [];
                var cssAttr = '';
                var cssVal = '';
                var cssStatements = fieldStyleString.split(";");  
                cssStatements.forEach(function(statement){
                    if(statement.length > 0) {
                        var cssArray = statement.split(":");
                        var cssAttr = cssArray[0];
                        var cssVal = cssArray[1];
                        if(cssAttr) {
                            cssObj[cssAttr] = cssVal;
                        }
                        $fieldCell.css(cssObj);
                    }
                });                        
            }                       
        },
        
        setFieldInlineEditDisabled: function (name) {
            var fieldView = this.recordView.getFieldView(name);
            
            var removeInlineEditLinks = function(fieldView) {
                var $cell = fieldView.getCellElement();
                $cell.find('.inline-save-link').remove();
                $cell.find('.inline-cancel-link').remove();
                $cell.find('.inline-edit-link').remove(); 
                fieldView.reRender(true);
            }
            
            if(fieldView != null) {
                removeInlineEditLinks(fieldView);   
            } else {
                this.recordView.once('after:render', function () {
                    fieldView = this.recordView.getFieldView(name);
                    removeInlineEditLinks(fieldView);                    
                }, this);                                    
            }
            
        },
        
        setFieldInlineEditEnabled: function (name) {
            var fieldView = this.recordView.getFieldView(name);
            
            var initInlineEdit = function(fieldView) {
                var $cell = fieldView.getCellElement();
                var $editLink = $('<a href="javascript:" class="pull-right inline-edit-link hidden"><span class="fas fa-pencil-alt fa-sm"></span></a>');
                if ($cell.length == 0) {
                    fieldView.once('after:render', function () {
                        initInlineEdit(fieldView);
                    }, fieldView);
                    return;
                }
                $cell.prepend($editLink);
                $editLink.on('click', function () {
                    fieldView.inlineEdit();
                }.bind(fieldView));
                $cell.on('mouseenter', function (e) {
                    e.stopPropagation();
                    if (fieldView.disabled || fieldView.readOnly) {
                        return;
                    }
                    if (fieldView.mode == 'detail') {
                        $editLink.removeClass('hidden');
                    }
                }.bind(fieldView)).on('mouseleave', function (e) {
                    e.stopPropagation();
                    if (fieldView.mode == 'detail') {
                        $editLink.addClass('hidden');
                    }
                }.bind(fieldView));                
            }.bind(this);    
            
            if(fieldView != null) {
                initInlineEdit(fieldView);                
            } else {
                this.recordView.once('after:render', function () {
                    fieldView = this.recordView.getFieldView(name);                    
                    initInlineEdit(fieldView);
                }, this);                                    
            }                        
        }
        
                
    });
});

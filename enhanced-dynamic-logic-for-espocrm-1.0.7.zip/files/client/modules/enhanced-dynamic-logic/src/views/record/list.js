/************************************************************************
 * This file is part of EspoCRM.
 *
 * EspoCRM - Open Source CRM application.
 * Copyright (C) 2014-2019 Yuri Kuznetsov, Taras Machyshyn, Oleksiy Avramenko
 * Website: https://www.espocrm.com
 *
 * EspoCRM is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * EspoCRM is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with EspoCRM. If not, see http://www.gnu.org/licenses/.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "EspoCRM" word.
 * 
 * Enhanced Dynamic Logic - Open source plug in module for EspoCRM
 * Copyright (C) 2020 Omar A Gonsenheim
 ************************************************************************/

Espo.define('enhanced-dynamic-logic:views/record/list', ['views/record/list','enhanced-dynamic-logic:enhanced-dynamic-logic'], function (Dep,EnhancedDynamicLogic) {

    return Dep.extend({
 
        dynamicLogicDefs: {},
        dynamicCss: [],
        dynamicLogic: null,
        isChildDlActive: false,
        
        init: function () {
            // execute the parent "init" function from views/record/list
            Dep.prototype.init.call(this);
            //console.log("list.js init()");
        },

        setup: function () {
            // execute the parent "setup" function from views/record/list
            Dep.prototype.setup.call(this);
            // set up the enhanced dynamic logic functionality if the collection is not empty
            this.dynamicLogicDefs = this.getMetadata().get('clientDefs.' + this.collection.entityType + '.dynamicLogic');
            this.dynamicLogic = new EnhancedDynamicLogic(this.dynamicLogicDefs, this);   
            this.dynamicLogic.viewMode = "list";            
            this.dynamicLogic.modelsArr = this.collection.models;
            //console.log("list.js current collection: ",this.collection);
            this.listenTo(this.collection,'holdListDynamicLogicProcess', function(){
                this.isChildDlActive = true;
                //console.log("list.js collection:holdListDynamicLogicProcess trigger was received");
            },this);

            this.listenTo(this.collection,'releaseListDynamicLogicProcess', function(){
                this.isChildDlActive = false;
                //console.log("list.js collection:releaseListDynamicLogicProcess");
            },this);

            this.listenTo(this.collection,'runListDynamicProcess', function(){
                if(this.collection.length > 0) {                    
                    this.dynamicLogic.process();
                    //console.log("list.js collection:runListDynamicProcess");
                }    
            },this);

            this.listenTo(this,'after:render', function(){
                //console.log("list.js collection:change");
                if(this.collection.length > 0) {                    
                    this.dynamicLogic.process(); 
                }    
            },this);            
            
            this.listenTo(this.collection,'change', function(){
                //console.log("list.js collection:change");
                if(!this.isChildDlActive) {
                    this.dynamicLogic.process();
                }
            },this);
            
            this.listenTo(this.collection,'sync', function(){
                //console.log("list.js collection:sync");
            },this);             
        },

        isFullyRendered: function () {
            return this._isFullyRendered;
        },

        // function invoked by enhanced-dynamic-logic:enhanced-dynamic-logic.js        
        setListFieldCss: function (cssListData) {    
            this.processCss(cssListData);            
        },
        
        processCss: function(cssListData) {
            // apply conditional css if the list view is currently rendered
            var rows = $('tr.list-row').length;
            if(rows > 0) {
                cssListData.forEach(function(rowData){
                    rowData.forEach(function (fieldData) {
                        var modelId = fieldData.modelId;
                        var fieldName = fieldData.field;  
                        var cssObj = {};
                        var cssArray = [];
                        var cssAttr = '';
                        var cssVal = '';
                        var cssStatements = fieldData.css.split(";");
                        cssStatements.forEach(function(statement){
                            cssArray = statement.split(":");
                            cssAttr = cssArray[0];
                            cssVal = cssArray[1];
                            if(cssAttr) {
                                cssObj[cssAttr] = cssVal;
                            }    
                        });                     
                        var $fieldCell = $('tr.list-row[data-id="' +modelId+ '"]>td.cell[data-name="' + fieldName + '"]');                    
                        if($fieldCell.length > 0) {
                            $fieldCell.css(cssObj);
                        } else {     
                            console.log("ERROR $fieldCell not defined. enhanced-dynamic-logic:views/record/list # 91");
                        }
                    }, this); 
                }, this);                
            }            
        }
        
    });
});
